import random;
A=65500
B=65534
resultList=random.sample(range(A,B+1),8);
#print str(resultList)[1:len(str(resultList)) - 1]
for i in resultList: 
	print "%d;" %i,

