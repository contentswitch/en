#!/bin/bash

checkpid(){

for ((i=1;i<=8;i++))
do
        fc_pid=$(pgrep -lf " -N -D -A 8 -a $i -f /usr/local/squid/etc/squid.conf"|awk '{print $1}')
        if [[ -z $fc_pid ]];then
                echo "-N -D -A 8 -a $i -f /usr/local/squid/etc/squid.conf" > tmp
        fi
done

}

detect(){
result=$(python 1.py|sed 's/[ ]*//g')
#echo $result |awk -F "," '{$1;$2;}'
str2="mod_listen_port ports=${result}  options=\"accel vhost vport allow-direct http11\" on"
echo $str2
str1='''mod_listen_port ports=.* options="accel vhost vport allow-direct http11" on'''
sed  -in-place  "s/$str1/$str2/g" squid.conf
#service flexicache reload 
service flexicache restart
wait
sleep 3

#checkpid
#sleep 3
#while read line
#do
#	fc_pid=$(pgrep -lf "$line"|awk '{print $1}')
#	if [[ -z $fc_pid ]];then
#	   echo "error:$line"
#	fi

#done < tmp


for port in $(echo $result |sed 's/;/ /g')
do
    num=$(netstat -antp |grep $port|grep LISTEN |wc -l)
    if [ $num -ne 1 ];then
	 sleep 5
	 num=$(netstat -antp |grep $port|grep LISTEN|wc -l)
	 if [ $num -ne 1 ];then
		echo -e "[info]$port error\n"
		netstat -antp |grep $port
		#return 100
	 fi
    else
	 echo -e "[info]$port ok\n"
         status=$(curl -so /dev/null -w %{http_code} "http://zb.iptv.gd.cn:30001/111.30.78.145:9090/mpeg/mpeg1/rc/ott/TJ3_1000/TJ3_1000_148887626.ts" -x 127.0.0.1:$port)
	 if [[ "$status" != "200" ]];then
		echo -e "[curl]$port error\n"
	 else
		echo -e "[curl]$port ok\n"
	 fi
		
    fi
done
}

while [ "d" == "d" ]
do
       #	result=$(detect|awk '{print $2}') 
	#if [ "$result" == "error" ];then
	#	break
	#fi
        detect
        #curl -o /dev/null "http://zb.iptv.gd.cn:30001/111.30.78.145:9090/mpeg/mpeg1/rc/ott/TJ3_1000/TJ3_1000_148887626.ts" -x 127.0.0.1:30001
	if [ $? -eq 100 ];then
		break
		#echo "100"
        fi
done
