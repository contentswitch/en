rm -f /usr/local/squid/bin/lscs/conf/nginx.conf
cp -v nginx.conf /usr/local/squid/bin/lscs/conf/nginx.conf

rm -f /usr/local/squid/etc/squid.conf /usr/local/squid/etc/domain.conf /usr/local/squid/etc/refreshd.conf
cp -v ./squid.conf /usr/local/squid/etc/
cp -v ./domain.conf /usr/local/squid/etc/
cp -v ./refreshd.conf /usr/local/squid/etc/

service flexicache restart 
wait
service named restart 
