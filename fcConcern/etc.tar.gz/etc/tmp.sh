#!/bin/bash
last_pid="1000"
while [[ "debug" == "debug" ]]
do
	service flexicache restart
	sleep 20
   	pid=$(pgrep -lf tencent_log|awk '{print $1}')
        if [ -z "$pid" -o "$pid" == "$last_pid" ]
	then
		echo "this time pid:$pid,The last time the pid:$pid2"
		break
	fi
	last_pid=$pid
done
