#!/bin/bash

while [ "d" == "d" ]
do
  	service flexicache restart
	wait && sleep 10
	while read url
	do
   		cname=$(echo $url|awk -F "?" '{print $1}'|awk -F "/" '{print $4}')
   		curl -vo $cname --max-time 30  "$url" -x 127.0.0.1:88
	done < url
	sleep 1

done
