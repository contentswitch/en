#!/bin/bash
for ((i=1;i<=100;i++))
do
	nc -w 1200 127.0.0.1 18003 &
done
