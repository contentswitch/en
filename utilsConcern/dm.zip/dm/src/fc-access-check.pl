#!/usr/bin/perl

use strict;
use warnings;
use LWP::UserAgent;
use POSIX;
use List::MoreUtils qw(uniq);
# ���ű����� DM ����ҽű�, ��Ҫ���ڼ�����ڵĵ�������־�ļ�����־��¼��������.
# ֱ���� DM �� MOVE �����������ļ��е� PostCommand ����ѡ��������ִ�б��ű��Ϳ���.

my $href;
my $alertThresh = 60;
my $app = "CPISFC";

open my $fh, ">>", "/tmp/fc-access-check.log";

logmsg($fh, "ִ�� $app ������־�����Լ��...");
if ( @ARGV == 1  and $ARGV[0] eq "error" ) {
    logmsg($fh, "service fc rotate failed, will send warings to IMS");
    $href = getpostinfo($app);
    postToIms( $href );
    exit 1;
}
elsif (@ARGV == 1 and $ARGV[0] =~ /\d+/) {
    $alertThresh = $ARGV[0];
}
else {
    logmsg($fh, "Invalid Args: @ARGV");
}

# �� DM �ĳ���Ŀ¼����������һ���ļ����ڼ�¼ÿ�εĶ�����ʱ�����ֵ

my $logpath = "/data/proclog/log/squid/access/.upload";
my $recordfile  = "/data/proclog/log/squid/access/.upload/record";
my $logfile = `ls -rt $logpath/*fc-access.log.* | tail -1`;
my $fileCount = `ls -rt $logpath/*fc-access.log.* | wc -l`;
chomp ($logfile);
chomp ($fileCount);

if ( ! -f $logfile) {
    logmsg($fh, "logfile -$logfile- not exits");
    exit 0;
}

my $isEmpty = "no";
$isEmpty = "yes" if ! -s $logfile;

my $firstlinetime = `head -1 $logfile | awk '{print \$1}'`; 
my $lastlinetime = `tail -1 $logfile | awk '{print \$1}'`;
my $recordtime = `head -1 $recordfile 2>/dev/null`;
chomp ($firstlinetime);
chomp ($lastlinetime);
chomp ($recordtime);

$recordtime = time() if ! $recordtime;

updateRecord($lastlinetime);

my $timeDiff = $firstlinetime - $recordtime;
$timeDiff = sprintf ("%.3f",$timeDiff);

# ��������Ϊ����Ҫ�澯������ ���� ims ȥ

if ( $timeDiff >= $alertThresh or $isEmpty eq 'yes' or $fileCount != 1)
{
    $href = getpostinfo( $app, $timeDiff, $isEmpty, $fileCount );
    postToIms( $href );
}

exit 0;


sub postToIms {
    
    my $postinfo = shift;
    my $path = "monitorservice/commonmonitorsvr/";
    my $ua = LWP::UserAgent->new( 
        agent   => 'ChinaCache-CPISFC_DM',
        timeout => 5,
    );
    my @ip = dig( 'imsapi.chinacache.g.xgslb.net' );
    return if @ip == 0;
    my $idx = 0;
    
    my $request = new HTTP::Request( POST => "http://$ip[$idx]/$path" );
    $request->content( $postinfo );
    my $try = 2;
    while ($try--) {
        my $response = $ua->request( $request );
        if ( $response->is_success ){
            last;
        } 
        else {
            logmsg($fh, "alert to IMS failed: " . $response->status_line);
        }
        if ( @ip > 0 ){
            $idx = ( $idx + 1 )%@ip;
            $ua->default_header( Host => $ip[$idx] );
            $request->uri( "http://$ip[$idx]/$path" );
        }
    }

}


sub getpostinfo {
    my ($app, $timeDiff, $isEmpty, $fileCount ) = @_;
    
    my $sn = `cat /sn.txt`;
    chomp $sn;
    my $now = time();    
    my $postinfo  = "---\n"
                   . "Application: $app\n"
                   . "DeviceID: $sn\n"
                   . "Level: alert\n"
                   . "Source: DM\n"
                   . "Timestamp: $now\n"
                   . "Detail:\n";

    if ( defined $timeDiff or defined $isEmpty or defined $fileCount ) {
        $postinfo .= "  - msgID: ACCESS_CHECK\n";
        
        if ( defined $isEmpty and $isEmpty eq 'yes' ) {
            $postinfo .= "    fileEmpty: $isEmpty\n";
            logmsg($fh, "Need alert to IMS: isEmpty $isEmpty" );
        }

        if ( defined $fileCount and $fileCount != 1 ) {
            $postinfo .= "    fileCount: $fileCount\n";
            logmsg($fh, "Need alert to IMS: fileCount $fileCount" );
        }

        if ( defined $timeDiff and $timeDiff > $alertThresh ) {
            $postinfo .= "    timeDiff: $timeDiff\n";
            logmsg($fh, "Need alert to IMS: timeDiff $timeDiff" );
        }
    }        
    else {
        $postinfo .= "  - msgID: ACCESS_ROTATE_FAILED\n";
    }

    return $postinfo;
}
sub logmsg {
    my ($fh, $msg) = @_;

    my $now = strftime "%Y-%m-%d %H:%M:%S", localtime;

    print $fh "$now $msg\n";
}

sub updateRecord {
    my $lastTs = shift @_;
    open my $fh, ">", $recordfile;
    print $fh "$lastTs\n";

    close $fh;
}

sub dig {
    my $domain = shift;

    if ( $domain =~ /^\d+\.\d+\.\d+\.\d+$/ ){
        return $domain;
    }

    my $res = new Net::DNS::Resolver(
        nameservers => [qw(
            8.8.8.8
            8.8.4.4
            114.114.114.114
        )]
    );

    my @ip;
    my $ip;

    my $query = $res->query( $domain, 'A' );
    if ( not $query ){
        return;
    }

    foreach my $rr ( $query->answer ) {
        next unless $rr->type eq 'A';
        next unless $rr->name eq $domain;
        next unless defined $rr->address;
        $ip = $rr->address;
        push @ip, $ip;
    }

    @ip = uniq @ip;

    if ( @ip == 0 ){
        print "DNS ����ʧ��: $domain ����û�з����κ� IP��";
    }

    if( wantarray ){
        return @ip;
    }
    else {
        return $ip[0];
    }

    return $ip;
}
