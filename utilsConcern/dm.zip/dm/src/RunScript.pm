# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package RunScript;

sub cpsRun {
    my ($kernel, $session, $heap) = @_[ KERNEL, SESSION, HEAP ];
    my ($timeout, $cmd) = @_[ ARG0..$#_ ];

    create POE::Session(
        package_states => [
            (__PACKAGE__) => [ qw(
                _start appClosed gotAppError gotAppOutput jobTimeout _stop
            ) ],
        ],
        heap => {
            class   => $class,
            dirDesc => $dirDesc,

        },
    );

    my $wheel = new POE::Wheel::Run(
        Program         => sub { my $cmd = shift; exec $cmd },
        ProgramArgs     => [ $cmd ],
        StdoutEvent     => 'gotAppOutput',
        StderrEvent     => 'gotAppError',
        CloseEvent      => 'appClosed',
        StdoutFilter    => new POE::Filter::Line(),
    ) or return;

    my $wheel_id = $wheel->ID;

    my $alarm_id = $kernel->delay_set( jobTimeout => $timeout => $wheel_id );

    $heap->{jobs}->{$wheel_id}->{wheel} = $wheel;
    $heap->{jobs}->{$wheel_id}->{timer} = $alarm_id;
    $heap->{jobs}->{$wheel_id}->{infoName} = $infoName;
}

sub waitRun {
}

sub appClosed {
    my ($kernel, $heap, $wheel_id) = @_[KERNEL, HEAP, ARG0];

    my $error = $heap->{jobs}->{$wheel_id}->{error};
    my $name = $heap->{jobs}->{$wheel_id}->{infoName};

    if ( defined $error ){
        $error =~ s/\s+$//;
        logmsg( "�ɼ� $name ʱ��������: \n$error" );
    }

    # ɾ����ʱ��
    $kernel->alarm_remove( $heap->{jobs}->{$wheel_id}->{timer} );
    delete $heap->{jobs}->{$wheel_id};
}

sub gotAppError {
    my ($kernel, $session, $heap) = @_[ KERNEL, SESSION, HEAP ];
    my ($line, $wheel_id) = @_[ ARG0..$#_ ];

    $line =~ s/\s*at \S+ line \d+.*$//g;
    $line =~ s/\s+$//;

    $heap->{jobs}->{$wheel_id}->{error} .= "$line\n";
}

sub gotAppOutput {
    my ($kernel, $session, $heap) = @_[ KERNEL, SESSION, HEAP ];
    my ($value, $wheel_id) = @_[ ARG0..$#_ ];

    my $name = $heap->{jobs}->{$wheel_id}->{infoName};

    # ֻȡ��һ��ֵ��֮���ֵȫ������
    if ( not defined $heap->{result}->{$name} ) {
        $heap->{result}->{$name} = $value;
    }

    # ɾ������
    $heap->{jobs}->{$wheel_id}->{wheel}->kill(9);
}

sub jobTimeout {
    my ($kernel, $session, $heap) = @_[ KERNEL, SESSION, HEAP ];
    my ($wheel_id) = @_[ ARG0..$#_ ];

    my $name = $heap->{jobs}->{$wheel_id}->{infoName};

    logmsg( "�ɼ� $name ��ʱ��" );

    # ɾ����ʱ��
    $kernel->alarm_remove( $heap->{jobs}->{$wheel_id}->{timer} );
    # ɾ������
    $heap->{jobs}->{$wheel_id}->{wheel}->kill(9);
}

1;

1;
