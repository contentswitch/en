package FtpClient;

use strict;
use warnings;
use Smart::Comments;

use File::Basename;

# ���� Time::HiRes ������ POE �ĸ߾��ȼ�ʱ����
use Time::HiRes;
use POE;
use PoeHelper;

use WWW::Curl::Easy;
use WWW::Curl::Multi;

use Utils;

sub spawn {
    my $class = shift;
    my $cfg = shift || {};

    spawnSession( qw(
        setServer
        upload download

        perform errorCodeInit allocConnDesc freeConnDesc
    ), {
        cfg => $cfg
    });
}

event _start {
    alias_set 'FTP';

    my $curlm = new WWW::Curl::Multi;
    $heap->{curlm} = $curlm;

    # ���ӳأ��� {$serverName, $user} ���� hash
    $heap->{connPool} = {};

    call FTP => 'errorCodeInit';
}

event perform {
    # 0, ���û�л�����ֱ�ӷ��أ�����ִ�У�
    return if $box->{activeHandles} == 0;

    # 1, ִ��һ�� perform��������л����ͼƻ��ٴ�ִ��
    my $activeTransfers = $heap->{curlm}->perform();
    delay perform => 0.1 if $activeTransfers;   # TODO: �����Ż�

    # 2, �����������δ���٣��ͷ���
    return if $activeTransfers == $box->{activeHandles};

    # 3, ����˵��������������ɣ���Ҫ������Ϣ
    while( my ($id, $errNo) = $heap->{curlm}->info_read ){
        last if not defined $id;
        $box->{activeHandles}--;

        my $errType     = $cfg->{typeOfCurlError}->{$errNo} || 'unknown';
        my $taskInfo    = delete $box->{taskList}{$id};
        my $origin      = delete $taskInfo->{sender};
        my $connDesc    = delete $taskInfo->{connDesc};
        my $curl        = $connDesc->{curl};

        delete $taskInfo->{fh};
        delete $taskInfo->{id};

        yield freeConnDesc => $connDesc;

        if ( $errType eq 'ok' ){
            my $totalTime = $curl->getinfo( CURLINFO_TOTAL_TIME );
            my $speed = int( $taskInfo->{bytes} / $totalTime );
            post $origin => uploadDone => $taskInfo => ($speed, $totalTime);
        }
        elsif ( $errType eq 'network' and $taskInfo->{retries}++ < $taskInfo->{retry} ){
            yield upload => $taskInfo;
        }
        else{
            my $errMsg = $curl->strerror($errNo);
            post $origin => uploadFailed => $taskInfo => ($errType, $errNo, $errMsg);
        }
    }
}

event setServer {
}

event upload( $taskInfo ){
    my $fh = new IO::File $taskInfo->{file}, 'r';
    if ( not defined $fh ){
        post $sender => uploadFailed => $taskInfo => (fatal => -1 => '���ļ�ʧ��');
        return;
    }

    binmode $fh;

    my ($connDesc, $errNo, $errMsg) = call $session => allocConnDesc => $taskInfo;
    if ( not defined $connDesc ){
        errlog( FTP => '����ʧ�ܡ�' );
        my $type = $cfg->{typeOfCurlError}->{$errNo} || 'unknown';
        post $sender => uploadFailed => $taskInfo => ($type => $errNo => $errMsg);
        return;
    }

    my $curl = $connDesc->{curl};

    runlog( FTP => '�����ѷ��䡣' );

    $box->{activeHandles}++;

    my $id = allocTaskID( $box );
    $taskInfo->{id}         = $id;
    $taskInfo->{connDesc}   = $connDesc;
    $taskInfo->{fh}         = $fh;
    $taskInfo->{sender}     = $sender;
    $box->{taskList}{$id}   = $taskInfo;

    runlog( FTP => 'Ϊ�ļ�', $taskInfo->{file}, "������ ID $id" );

    $curl->setopt( CURLOPT_UPLOAD, 1 );
    $curl->setopt( CURLOPT_URL, makeUrl($taskInfo) );
    $curl->setopt( CURLOPT_READFUNCTION, \&getData );
    $curl->setopt( CURLOPT_READDATA, $taskInfo );
    $curl->setopt( CURLOPT_DEBUGDATA, $taskInfo );
    $curl->setopt( CURLOPT_NOBODY, 0 );
    # $curl->setopt( CURLOPT_QUOTE, [ 'REST 0' ] );
    $curl->setopt( CURLOPT_PRIVATE, $id );

    $heap->{curlm}->add_handle( $curl );

    delay perform => 0;
}

event download( $url, $file ){
    ### TODO
}

sub allocTaskID {
    my $box = shift;

    my $taskID = my $prevTaskID = $box->{lastTaskID} || 0;

    my $loop = 0;
    while(1){
        $taskID++;
        if ( $taskID > 9999 ){
            $taskID = 1;
            $loop = 1;
        }
        if ( $loop and $taskID > $prevTaskID ){
            runlog( AGT => "���� ID ��Դ�ľ���" );
            return;
        }

        last if not exists $box->{taskList}{$taskID};
    }

    $box->{lastTaskID} = $taskID;
    return $taskID;
}

event allocConnDesc( $taskInfo ){
    my $addr = $taskInfo->{ip} . ':' . $taskInfo->{port};
    my $user = $taskInfo->{user};
    if (    exists  $heap->{connPool}{$addr}
        and exists  $heap->{connPool}{$addr}{$user}
    ){
        my $idlePool = $heap->{connPool}{$addr}{$user};
        my $connDesc = pop @$idlePool;
        my $curl = $connDesc->{curl};
        #delete $idlePool->{$curl};

        $connDesc->{state} = 'busy';
        $connDesc->{usesCount}++;
        $connDesc->{lastUseTime} = time;
        # $heap->{connPool}{$addr}{$user}->{busy}->{$curl} = $connDesc;

        return $connDesc;
    }

    my ($curl, $errNo, $errMsg) = createCurlHandle( $cfg, $taskInfo->{ip}, $taskInfo->{port}, $taskInfo->{user}, $taskInfo->{pass} );
    if ( not defined $curl ){
        return (undef, $errNo, $errMsg);
    }

#    $heap->{connPool}{$addr}{$user}{busy}->{$curl} = {
#        curl        => $curl,
#        state       => 'busy',
#        usesCount   => 1,
#        lastUseTime => time,
#    };

    my $connDesc = {
        curl        => $curl,
        state       => 'busy',
        usesCount   => 1,
        lastUseTime => time,
        addr        => $addr,
        user        => $user,
    };

    return $connDesc;
}

event freeConnDesc( $connDesc ){
    my $addr = $connDesc->{addr};
    my $user = $connDesc->{user};
    $connDesc->{state}          = 'idle';
    $connDesc->{lastUseTime}    = time;
    push @{ $heap->{connPool}{$addr}{$user} }, $connDesc;
}

sub createCurlHandle {
    my $cfg = shift;
    my ($ip, $port, $user, $pass ) = @_;

    my $curl = new WWW::Curl::Easy;

    #
    # ���ǰ� CURL �����ѡ��ֳ����ࣺһ���ǲ���ģ�һ�����ױ�ģ�
    # �ڱ������У����ǽ�������Щ�����ѡ�����һЩ�������޸ĵ�ѡ�
    # ��ŵ� resetCurlHandle ��ȥ���ã��Ա��ڵ���������ʱ��������һ��
    # ����ʱ�����á�
    #

    # Ŀ¼������ʱ���Ƿ񴴽�Ŀ¼
    $curl->setopt( CURLOPT_FTP_CREATE_MISSING_DIRS, 1 );

    # ��ʼĿ¼
    $curl->setopt( CURLOPT_URL, "ftp://$ip:$port/" );

    $curl->setopt( CURLOPT_USERNAME, $user );
    $curl->setopt( CURLOPT_PASSWORD, $pass );

    # TODO: mode
    if ( 0 ){
        # PORT ģʽ
        # TODO: �Ƿ���Ҫ���� PORT ָ��͵� IP ��ַ����Ҫ�����о�һ�¡�
        # libcurl manual ��˵������Ϊ "-" �ͻ��Զ�ѡ��ȱʡ IP�������ȱʡ IP ������ʲô��
        # ����Ҫ hack һ��Դ���֪����
        $curl->setopt( CURLOPT_FTPPORT, "-" );
    }
    elsif ( 1 ){
        # PASSIVE ģʽ
        $curl->setopt( CURLOPT_FTPPORT, undef );
    }
    else{
        # AUTO ģʽ
        # TODO: Ŀǰ�в�֧���Զ�̽��ģʽ����� AUTO ģʽʵ�����ǲ�֧�ֵģ��� PASSIVE ģʽ����
        $curl->setopt( CURLOPT_FTPPORT, undef );
    }

    if ( 0 ){
        # �ֳɶ�� CWD ָ�������Ŀ¼��
        $curl->setopt( CURLOPT_FTP_FILEMETHOD, CURLFTPMETHOD_MULTICWD );
    }
    else{
        # CWD ָ��һ����λ��CWD ʱ��������·��
        $curl->setopt( CURLOPT_FTP_FILEMETHOD, CURLFTPMETHOD_SINGLECWD );
    }

    # �趨��ʱ
    $curl->setopt( CURLOPT_CONNECTTIMEOUT, $cfg->{ConnectTimeout} || 3 );
    $curl->setopt( CURLOPT_FTP_RESPONSE_TIMEOUT, $cfg->{ConnectTimeout} || 3 );

    # ���ٹ��ܣ��ܺ���
    $curl->setopt( CURLOPT_MAX_SEND_SPEED_LARGE, $cfg->{MaxSpeed} * 1024 ) if defined $cfg->{MaxSpeed};
    $curl->setopt( CURLOPT_LOW_SPEED_LIMIT, $cfg->{LowSpeedLimit} * 1024 ) if defined $cfg->{LowSpeedLimit};
    $curl->setopt( CURLOPT_LOW_SPEED_TIME, $cfg->{LowSpeedTime} ) if defined $cfg->{LowSpeedTime};

    resetCurlHandle( $curl );

    my $retCode = $curl->perform();
    if ( $retCode != CURLE_OK ){
        errlog( FTP => "����λ�� $ip:$port ������ʱ��������: [$retCode]", $curl->strerror($retCode) );
        return (undef, $retCode, $curl->strerror($retCode));
    }

    runlog( FTP => "���� $ip:$port �Ѵ�����" );
    return $curl;
}

sub resetCurlHandle {
    my $curl = shift;

    # ֻ���ӣ��������κ����
    $curl->setopt( CURLOPT_NOBODY, 1 );

    if ( 1 ){
        $curl->setopt( CURLOPT_VERBOSE, 1 );
        $curl->setopt( CURLOPT_DEBUGFUNCTION, \&curlDebugLog );
    }
    else{
        $curl->setopt( CURLOPT_VERBOSE, 0 );
        $curl->setopt( CURLOPT_DEBUGFUNCTION, undef );
    }

    # $curl->setopt( CURLOPT_PREQUOTE, [] );    # WWW::Curl ��֧�� PREQUOTE
    $curl->setopt( CURLOPT_QUOTE, [] );
    $curl->setopt( CURLOPT_POSTQUOTE, [] );

    $curl->setopt( CURLOPT_DEBUGDATA, {} );

    $curl->setopt( CURLOPT_HEADERFUNCTION, undef );
    $curl->setopt( CURLOPT_HEADERDATA, undef );
    $curl->setopt( CURLOPT_WRITEFUNCTION, undef );
    $curl->setopt( CURLOPT_WRITEDATA, undef );

    $curl->setopt( CURLOPT_READDATA, undef );
    $curl->setopt( CURLOPT_READFUNCTION, undef );

    $curl->setopt( CURLOPT_UPLOAD, 0 );
}

sub curlDebugLog {
    my ($msg, $cxt, $type) = @_;

    my $sig = {
        CURLINFO_TEXT()         => '*', 
        CURLINFO_HEADER_IN()    => '<', 
        CURLINFO_HEADER_OUT()   => '>', 
        CURLINFO_DATA_IN()      => '<', 
    }->{$type} or return 0;

    my $taskID = sprintf '%04d', ($cxt && $cxt->{id} || 0);

#    runlog( NET => $taskID, $sig, $msg );

    return 0;
}

sub getData {
    my ($len, $taskInfo) = @_;

    my $fh = $taskInfo->{fh};
    my $buf = '';
    my $bytes = $fh->sysread( $buf, $len );

    $taskInfo->{bytes} += $bytes;

    return $buf;
}

sub makeUrl {
    my $taskInfo = shift;

    my $addr = $taskInfo->{ip};
    my $port = $taskInfo->{port} || 21;
    my $fileName = basename $taskInfo->{file};
    my $postfix = basename $taskInfo->{postfix};
    my $dstPath = basename $taskInfo->{dstPath};

    my $url = "ftp://$addr:$port/$dstPath/$fileName$postfix";

    return $url;
}

sub ftplog {
    my $taskInfo = shift;

    runlog( FTP => $taskInfo->{id} => $taskInfo->{server} => @_ );
}

event errorCodeInit {
    # 0, ��������
    my @curlOK = (
        CURLE_OK,
        CURLE_PARTIAL_FILE,
    );

    # 1, ����ȡ��
    my @curlCancel = (
        CURLE_ABORTED_BY_CALLBACK,
    );

    # 2, ���ش���
    my @curlFatalError = (
        CURLE_UNSUPPORTED_PROTOCOL,
        CURLE_FAILED_INIT,
        CURLE_URL_MALFORMAT,
        CURLE_OUT_OF_MEMORY,
        CURLE_READ_ERROR,
        CURLE_FUNCTION_NOT_FOUND,
        CURLE_BAD_FUNCTION_ARGUMENT,
        CURLE_WRITE_ERROR,
    );

    # 3, Э�����
    my @curlProtocolWeird = (
        CURLE_FTP_WEIRD_SERVER_REPLY,
        CURLE_FTP_WEIRD_PASS_REPLY,
        CURLE_FTP_WEIRD_PASV_REPLY,
        CURLE_FTP_WEIRD_227_FORMAT,
        CURLE_FTP_COULDNT_SET_TYPE,
    );

    # 4, �������
    my @curlNetworkError = (
        CURLE_COULDNT_RESOLVE_PROXY,
        CURLE_COULDNT_RESOLVE_HOST,
        CURLE_COULDNT_CONNECT,
        CURLE_FTP_CANT_GET_HOST,
        CURLE_FTP_COULDNT_USE_REST,
        CURLE_SEND_ERROR,
        CURLE_RECV_ERROR,
        CURLE_OPERATION_TIMEDOUT,
    );

    # 5, �����������Ĵ���Ӧ��
    my @curlServerError = (
        CURLE_REMOTE_ACCESS_DENIED,
        CURLE_FTP_PORT_FAILED,
        CURLE_REMOTE_FILE_EXISTS,
        CURLE_BAD_CONTENT_ENCODING,
        CURLE_GOT_NOTHING,
        CURLE_RANGE_ERROR,
        CURLE_TOO_MANY_REDIRECTS,
        CURLE_HTTP_POST_ERROR,
        CURLE_INTERFACE_FAILED,
        CURLE_HTTP_PORT_FAILED,
        CURLE_UPLOAD_FAILED,
        CURLE_FTP_COULDNT_STOR_FILE,
        CURLE_FTP_COULDNT_RETR_FILE,
        CURLE_FTP_BAD_DOWNLOAD_RESUME,
        CURLE_FILE_COULDNT_READ_FILE,
        CURLE_QUOTE_ERROR,
        CURLE_LOGIN_DENIED,
        CURLE_FILESIZE_EXCEEDED,
        CURLE_SEND_FAIL_REWIND,
        CURLE_CONV_FAILED,
        CURLE_CONV_REQD,
        CURLE_REMOTE_FILE_NOT_FOUND,
        CURLE_HTTP_NOT_FOUND,
        CURLE_HTTP_RETURNED_ERROR,
    );

    # 6, ������̫���ܳ��ֵĴ���
    my @curlOtherError = (
        CURLE_LDAP_CANNOT_BIND,
        CURLE_LDAP_SEARCH_FAILED,
        CURLE_LDAP_INVALID_URL,
        CURLE_SSL_CONNECT_ERROR,
        CURLE_UNKNOWN_TELNET_OPTION,
        CURLE_TELNET_OPTION_SYNTAX,
        CURLE_SSL_PEER_CERTIFICATE,
        CURLE_SSL_ENGINE_NOTFOUND,
        CURLE_SSL_ENGINE_SETFAILED,
        CURLE_SSL_CERTPROBLEM,
        CURLE_SSL_CIPHER,
        CURLE_SSL_CACERT,
        CURLE_USE_SSL_FAILED,
        CURLE_SSL_ENGINE_INITFAILED,
        CURLE_TFTP_NOTFOUND,
        CURLE_TFTP_PERM,
        CURLE_REMOTE_DISK_FULL,
        CURLE_TFTP_ILLEGAL,
        CURLE_TFTP_UNKNOWNID,
        CURLE_TFTP_NOSUCHUSER,
        CURLE_SSL_CACERT_BADFILE,
        CURLE_SSH,
        CURLE_SSL_SHUTDOWN_FAILED,
    );

    my %errorType = (
        ok          => \@curlOK,
        fatal       => \@curlFatalError,
        network     => \@curlNetworkError,
        protocol    => \@curlProtocolWeird,
        server      => \@curlServerError,
        other       => \@curlOtherError,
    );

    my $typeOfCurlError = $cfg->{typeOfCurlError} = {};
    foreach my $type ( keys %errorType ){
        foreach my $code ( @{ $errorType{$type} } ){
            $typeOfCurlError->{$code} = $type;
        }
    }

    return;
}

1;
