# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package Utils;

use strict;
use warnings;
use Smart::Comments -ENV, '###';

use POSIX;
use File::Spec::Functions;
use File::Basename;
use File::Path qw(make_path);
use IPC::Open3;
use IO::Select;
use Carp qw(cluck);
use Net::DNS::Resolver;
use List::MoreUtils qw(uniq);
use POE::Component::IKC::ClientLite;

use constant LOG_DIR => '/var/log/ccamr';
use constant PID_DIR => '/var/run/ccamr';

use base qw(Exporter);
our @EXPORT = qw(
    runlog dbglog buglog errlog warnlog crash
    modifiedSince lastModifyTime inodeOf
    firstLineOf getHostname getDeviceID
    extendVar extendSize extendTime dig lcpLen
    getEnabledApps getAppList
    timeRun killProcessTree makePath
    LOG_DIR PID_DIR
    backup makeRequest safeZipFile 
);

$|=1;

sub modifiedSince {
    my ($file, $time, $delay) = @_;
    $delay ||= 5;

    my $modify = (stat $file)[9] or return;

    # $delay ��֮���޸ĵ��ļ���ʱ������
    if ( time() - $modify < $delay ){
        return 0;
    }

    if ( $modify > $time ){
        return 1;
    }

    return 0;
}

sub lastModifyTime {
    my $file = shift or return;

    my $time = (stat $file)[9];

    return $time;
}

sub inodeOf {
    my $path = shift;

    my $inode = (stat $path)[1];

    return $inode;
}

sub logmsg {
    my ($type, $tag, @info) = @_;

    my $now = strftime "%Y-%m-%d %H:%M:%S", localtime;
    $type = pack 'A3', $type;
    $tag = pack 'A3', $tag;

    my $allInfo = join ' ', @info;
    foreach my $line ( split /\r?\n/, $allInfo ){
        print "$type $tag $now $line\n";
    }
}

sub dbglog {
    logmsg( DBG => @_ );
}

sub buglog {
    logmsg( DBG => @_ );
    cluck( "���� BUG ��������" );
}

sub runlog {
    logmsg( RUN => @_ );
}

sub errlog {
    logmsg( ERR => @_ );
}

sub warnlog {
    logmsg( WRN => @_ );
}

sub crash {
    logmsg( SYS => @_ );
    exit 1;
}

###############################################################
# ����: ȡ�ļ���һ�е����ݣ��������������ʵ�����๦��
#
sub firstLineOf {
    my $file = shift;

    open my $fh, $file or return '';
    my $line = <$fh>;
    chomp $line;
    $line =~ s/^\s+|\s+$//g;

    return $line;
}

###############################################################
# ����: ȡ�豸��
#
sub getHostname {
    my $hostname = (uname)[1];
    return $hostname;
}

###############################################################
# ����: ȡ�豸ID
#
sub getDeviceID {
    my $deviceID = firstLineOf( '/sn.txt' ) || 'Unknown';
    return $deviceID;
}

#######################################################################
# ����: �����е�λ��ʱ��ת��������Ϊ��λ������
# ����: ����λ��ʱ��
#
sub extendTime {
    my $value = shift || 0;

    if ( $value =~ /^(\d+)s?$/ ){
        $value = $1;
    }
    elsif( $value =~ /^(\d+)m$/ ){
        $value = $1 * 60;
    }
    elsif( $value =~ /^(\d+)h$/ ){
        $value = $1 * 60 * 60;
    }
    elsif( $value =~ /^(\d+)d$/ ){
        $value = $1 * 60 * 60 * 24;
    }
    else{
        logmsg( "ʱ��������" );
        $value = 60;
    }

    return int($value);
}

#######################################################################
# ����: �� Unix ��Ԫ��ʱ��ת��������ɶ���ʱ���ַ���
# ����: ʱ���
#
sub makeHumanTime {
    my $time;

    return sprintf "%s (Unix Time: %d)", scalar localtime($time), $time;
}

#######################################################################
# ����: ���� PID �ļ�
# ����: �ļ���, PID
#
sub createPidFile {
    my ($file, $pid) = @_;

    # �����̺�д�� PID �ļ�
    open my $fh, '>', catfile( PID_DIR, "$file.pid" ) or die;
    print $fh "$pid\n";
    close $fh;
}


sub getWholeFile {
    my $file = shift;
    open my $fh, '<', $file or return;
    binmode $fh;
    my @line = <$fh>;
    if ( wantarray ){
        return @line;
    }
    else{
        return join '', @line;
    }
}

sub getHostName {
    return (uname)[1];
}

sub getNicIP {
    my $nic = shift;

    my $line = `ifconfig $nic | grep 'inet addr'`;
    my ($ip) = $line =~ /inet addr:(\S+)/;

    return $ip;
}

sub extendSize {
    my $value = shift;

    if ( $value =~ /[Bb]$/ ){
        return $`;
    }
    elsif ( $value =~ /[Kk]$/ ){
        return $` * 1024;
    }
    elsif ( $value =~ /[Mm]$/ ){
        return $` * 1024 * 1024;
    }
    elsif ( $value =~ /[Gg]$/ ){
        return $` * 1024 * 1024 * 1024;
    }

    return int($value);
}

sub extendVar {
    my $str = shift;
    my $vars = shift || {};

    my $now = time();
    my $timeStamp = strftime "%Y%m%d%H%M%S", localtime($now);
    my $hostName = getHostname();
    my $deviceID = getDeviceID();

    $str =~ s/{TIME}/$timeStamp/ige;
    $str =~ s/{HOSTNAME}/$hostName/ige;
    $str =~ s/{DEVICEID}/$deviceID/ige;

    foreach my $key ( keys %$vars ){
        my $value = $vars->{$key};
        $str =~ s/\Q{$key}\E/$value/ige;
    }

    return $str;
}

sub getEnabledApps {
    my $appList = callAMRd( 'list' ) or return;

    my @enabled = map { $_->{Name} } grep { $_->{Switch} eq 'enable' } @$appList;

    return \@enabled;
}

sub getAppList {
    return callAMRd( 'list' );
}

sub restartMftt {
    return callAMRd( restart => 'mftt' );
}

sub callAMRd {
    my $cmd = shift or return;
    my @args = @_;

    my $ip = '127.0.0.1';

    my $progName = basename $0;

    my $poe = create_ikc_client(
        ip          => $ip,
        port        => 21800,
        name        => "$progName-$$",
        serialiser  => 'POE::Component::IKC::Freezer',
    ) or do {
        errlog( POE => "�� AMR ͨ��ʧ��:" . POE::Component::IKC::ClientLite::error() );
        return;
    };

    my @result = $poe->call( "control/$cmd", @args ) or do{
        errlog( POE => $poe->error );
        return;
    };

    if ( wantarray ){
        return @result;
    }
    else{
        return $result[0];
    }
}

sub uptime {
    my $line = firstLineOf( '/proc/uptime' );

    my ($uptime, $idle) = split /\s+/, $line;

    return $uptime;
}

=item B<lcpLen>

����: ���� hostname

˵��: ���������� hostname ����󹫹�ǰ׺�ĳ���: 0 - ISP ����ͬ��1 - �� ISP ��ͬ��2 - ISP-���� ��ͬ��3 - ISP-����-С�ڵ� ��ͬ��4 - ����ͬһ̨������

=cut
sub lcpLen {
    my ($left, $right) = @_;    

    # ��������ʽ����
    my $format = qr/^[A-Z]{3}-[A-Z]{2}-[A-Z0-9]-[a-zA-Z0-9]{3,4}(-[A-Z]{3})?$/;
    if ( $left !~ $format or $right !~ $format ){
        return 0;
    }

    if ( substr( $left, 0, 3 ) ne substr( $right, 0, 3 ) ){
        return 0;
    }

    if ( substr( $left, 0, 6 ) ne substr( $right, 0, 6 ) ){
        return 1;
    }
    
    if ( substr( $left, 0, 8 ) ne substr( $right, 0, 8 ) ){
        return 2;
    }

    if ( $left ne $right ){
        return 3;
    }

    return 4;
}

=item B<dig>

����: $domain

˵��: �������������棺���������� POE �¼��������������еġ�

=cut
sub dig {
    my $domain = shift;

    if ( $domain =~ /^\d+\.\d+\.\d+\.\d+$/ ){
        return $domain;
    }

    my @nameServerList = qw(
            8.8.8.8
            202.205.0.1
            202.205.0.2
            114.114.114.114
            202.106.0.20
            42.62.11.133
            211.147.247.79
            42.62.11.134
            58.216.30.168
            61.240.138.136
            114.114.115.115
            8.8.4.4
    );
    my $res = new Net::DNS::Resolver(
        recurse     => 1,
        debug       => 0,
        retry       => 1,
        tcp_timeout => 2,
        udp_timeout => 2,
    );

    my @resolvIp;

    foreach my $nameserver ( @nameServerList ){
        $res->nameservers( $nameserver );
        my $query = $res->query( $domain, 'A' );

        if ( not $query ){
            errlog( DNS => "$domain ����ʧ��:", $res->nameservers, $res->errorstring );
            next;
        }

        foreach my $rr ( $query->answer ) {
            if ( $rr->type eq 'CNAME' ){
                runlog( DNS => '���� CNAME ����ѯ����', $domain, '=>', $rr->cname);
                $domain = $rr->cname;
            }
            next unless $rr->type eq 'A';
            next unless $rr->name eq $domain;
            next unless defined $rr->address;
            my $ip = $rr->address;
            runlog( DNS => "DNS �����ɹ�: $domain => $ip" );
            push @resolvIp, $ip;
        }
        last if @resolvIp > 0;
    }

    if ( @resolvIp == 0 ){
        errlog( DNS => "DNS ����ʧ��: $domain ����û�з����κ� IP��" );
        return;
    }

    @resolvIp = uniq @resolvIp;

    if( wantarray ){
        return @resolvIp;
    }
    else{
        return $resolvIp[0];
    }
}

=item B<timeRun>

����: $cmdLine, $timeout

˵��: �ڹ涨��ʱ������������

=cut
sub timeRun {
    my $cmd = shift;
    my $timeout = shift || 60;
    my $finalTime = time + $timeout;

    if ( $timeout <= 0 ){
        $finalTime = undef;
    }

    $SIG{PIPE} = 'IGNORE';

    my ($in, $out, $output);
    my $pid = eval { open3( $in, $out, $out, $cmd ) };

    if ( not $pid ){
        return ( error => "ִ���������: $!" );
    }

    my $s = new IO::Select( $out ); 
    while(1){
        my @ready = $s->can_read(1);
        if ( @ready ){
            my $line = <$out>;
            if ( defined $line ){
                $output .= $line;
            }
        }

        my $kid = waitpid( $pid, WNOHANG );
        if ( $kid > 0 ){
            if ( $? == -1 ){
                errlog( CMD => "ִ�� $cmd ����ʧ��: $!" );
            }
            elsif ( $? & 127 ) {
                my $msg = sprintf "ִ�� $cmd ����ʱ�����ź� %d, %s coredump �ļ���",
                   ( $? & 127 ), ( $? & 128 ) ? '������' : 'û������';
                errlog( CMD => $msg );
            }
            elsif ( $? != 0 ) {
                errlog( CMD => "���� $cmd �ķ������� $?��" );
            }

            last;
        }

        if ( defined $finalTime and time >= $finalTime ){
            killProcessTree( $pid );
            return ( timeout => "����ִ�г�ʱ��" );
        }
    }

    return ( ok => $output );
}

sub killProcessTree {
    my $which = shift;

    return unless -f "/proc/$which/status";

    my $map;
    while ( my $dir = glob "/proc/[0-9]*" ){
        next unless -d $dir and -f "$dir/status";
        open my $fh, '<', "$dir/status" or next;
        my %info = map { chomp; split /:\s+/, $_, 2 } <$fh>;
        my ($tgid, $pid, $ppid) = @info{qw(Tgid Pid PPid)};
        next if $pid != $tgid;  # skip thread
        $map->{$pid} = {};
        push @{ $map->{$ppid}->{childs} }, $pid;
    }

    return unless exists $map->{$which};

    my $getPids = sub {
        my ($map, $pid, $sub) = @_;
        my @list;

        push @list, $pid;
        foreach my $child ( @{ $map->{$pid}->{childs} || [] } ){
            push @list, $sub->( $map, $child, $sub );
        }

        return @list;
    };

    my @pids = $getPids->( $map, $which, $getPids );

    kill TERM => @pids;
    select undef, undef, undef, 0.25;
    kill KILL => @pids;

    do{ select undef, undef, undef, 0.25 } while waitpid( $which, WNOHANG ) != $which;
}

sub makePath {
    my $path = shift;

    my $err;
    make_path( $path, { error => \$err } );
    for my $diag ( @$err ) {
        my ($file, $message) = %$diag;
        chomp $message;
        if ( $file eq '' ) {
            errlog( MKD => "����Ŀ¼ $path ʱ��������: $message" );
        }
        else {
            errlog( MKD => "����Ŀ¼ $file ʱ��������: $message" );
        }
    }
}

sub backup {
    my ($file, $backupPath) = @_;

    makePath( $backupPath ) unless -d $backupPath;

    my $ok = File::Copy::move( $file => $backupPath );

    if ( not $ok ){
        my $opts = ConfigFile::getConfig( 'UploadOptions' );
        my $bakFileName = $file . $opts->{BackupOptions}{RenamePostfix};
        errlog( BAK => "�ƶ�����: $!���������ļ� $file => $bakFileName" );
        $ok = rename( $file, $bakFileName );
        
        if ( not $ok ){
            errlog( BAK => "������Ϊ��ʱ�ļ� $bakFileName ����: $!��ɾ���ļ� $file" );
            unlink $file;
            return 'delete';
        }
      
        return 'rename'; 
    }

    return 'normal';
}

sub makeRequest {
    my ($opts, $cont) = @_;    
    my $host = $opts->{Host};

    my $req;

    my $ip = dig( $host );

    if ( not defined $ip ){    
        errlog( REQ => "�������� $host ʧ�ܡ��޷�������" );
        return;
    }

    runlog( REQ => "���� $host ���Ϊ $ip" ) if $ip ne $host;
    my $url = "$opts->{Scheme}://$ip:$opts->{Port}$opts->{Path}";

    if ( $opts->{Method} eq 'GET' ){
        $url .= "?$cont";
        runlog( REQ => "$url" );
        $req = HTTP::Request->new( GET => $url );
    }
    else {
        $req = HTTP::Request->new( POST => $url );
        $req->content( $cont );
    }

    $req->header( 'Accept-Encoding' => 'gzip,deflate' );
    $req->header( Connection => 'close' );

    return $req;
}

sub safeZipFile {
    my ($action, $method, $fileName) = @_;

    my $cmd;
    my $zippedFileName;

    my $compressOptions = ConfigFile::getConfig("CompressOptions");
    my $retry = $compressOptions->{RetryTimes} || 3;

    my $origSize = -s $fileName;

    while( $retry > 0 ){
        if ( lc $method eq 'gzip' ){
            runlog( $action => "�� gzip ����ѹ�� ..." );
            $cmd = "gzip $fileName";
            $zippedFileName = "$fileName.gz";
        }
        elsif ( lc $method eq 'bzip2' ){
            runlog( $action => "�� bzip2 ����ѹ�� ..." );
            $cmd = "bzip2 $fileName";
            $zippedFileName = "$fileName.bz2";
        }
        elsif ( lc $method eq 'zip' ){
            runlog( $action => "�� zip ����ѹ�� ..." );
            $cmd = "zip $fileName.zip $fileName";
            $zippedFileName = "$fileName.zip";
        }
        elsif ( lc $method eq 'compress' ){
            runlog( $action => "�� compress ����ѹ�� ..." );
            $cmd = "compress $fileName";
            $zippedFileName = "$fileName.Z";
        }
        else{
            runlog( $action => "�� gzip ����ѹ�� ..." );
            $cmd = "gzip $fileName";
            $zippedFileName = "$fileName.gz";
        }

        runlog( $action => "call $cmd ..." );

        my $timeLimit = $compressOptions->{Timeout} || 300;
        my ($ret, $output) = timeRun( $cmd, $timeLimit );
        if ( $ret eq 'ok' and $? == 0 ){
            unlink $fileName;
            my $size = -s $zippedFileName;
            if ( $origSize > 0 ){
                my $p = sprintf "%d", $size * 100 / $origSize;
                runlog( $action => "ѹ����ɣ�ѹ����: $p%" );
            }
            else{ # ���ļ�
                runlog( $action => "ѹ����ɡ�" );
            }
            return ( $zippedFileName ) if( wantarray );
            last;
        }

        unlink $zippedFileName;
        errlog( $action => "ѹ��ʧ��: $output" );
        $retry--;
    }
}


1;
