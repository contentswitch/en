# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

#======================================
# �Ա� <zhaobin@chinacache.com>
# 20130107
# ChinaCache Ŀ¼�����ʹ��乤�ߵĽӿ�֮B<��������ϱ�ģ��>
#======================================

=head1 ����

StatusReporter.pm - Ŀ¼�����ʹ��乤�ߵĽӿ�֮B<��������ϱ�ģ��>

��ģ�鶨ʱ�ϱ����������

=head1 �÷�˵��

use StatusReporter;G

spawn StatusReporter;  # ������ Session �Զ����ṩ����

=cut

package StatusReporter;

use strict;
use warnings;

use Smart::Comments -ENV, '###';
use Perl6::Junction qw(all);
use POE qw(Component::Client::HTTP);
use Clone qw(clone);

use ConfigFile;
use Utils;

use HTTP::Request::Common qw(GET POST);
use URI;

=item B<spawn>

���룺��

˵��: �����ϱ��ϴ�״̬ Session

=cut

sub spawn {
    spawn POE::Component::Client::HTTP(
        Agent   => 'DM_SRT',
        Alias   => 'UA_SRT',
        MaxSize => 409600,
        Timeout => 10,
    );

    create POE::Session(
        package_states => [
            (__PACKAGE__) => [ qw(
                _start
                addInfo
                reportStatus
                reportDone
            ) ],
        ],
        heap => {
            dataList => {},
            status     => 'ready',
            interval   => getConfig( 'StatusReporterInterval' ) || 1800,
            shelflife  => 3 * 3600,
        },
    );
}

=item B<_start>

����: ��

˵��: �ϱ��ϴ���Ϣ�����¼�

=cut
sub _start {
    my ($kernel, $session, $heap) = @_[KERNEL, SESSION, HEAP];

    $kernel->alias_set( 'SRT' );

    runlog( SRT => '��������ϱ�ģ��������' );
    my $opts = getConfig( 'DMAPIOptions' );
    $heap->{reqOptions} = clone $opts;
    $heap->{reqOptions}{Method} = $opts->{Usage}{StatusReporter}{Method};
    $heap->{reqOptions}{Path} = $opts->{Usage}{StatusReporter}{Path};

    $kernel->delay( 'reportStatus' => $heap->{interval});

}


=item B<reportStatus>

����: ��

˵��: �ϱ�״̬��Ϣ

=cut
sub reportStatus{
    my ($kernel, $session, $heap) = @_[KERNEL, SESSION, HEAP];

    my $interval = $heap->{interval};
    # �����ϱ�
    $kernel->delay( reportStatus => $interval );

    return if $heap->{status} eq 'reporting';

    # ��������
    my $cont = getConfig( 'Hostname' ); 
    $cont .= "\n";
    foreach my $file ( keys %{$heap->{dataList}{done}} ){
        $cont .= $heap->{dataList}{done}{$file}{data} . "\n";
    }

    $cont .= "\n\n";

    foreach my $file ( keys %{$heap->{dataList}{todo}} ){
        $cont .= $heap->{dataList}{todo}{$file}{data} . "\n";
    }

    return if $cont eq "";
    my $req = makeRequest( $heap->{reqOptions}, $cont);

    if ( not defined $req ){
        delTimeoutData( $heap );
        return;
    }

    $heap->{status} = 'reporting';
    $kernel->post( UA_SRT => request => reportDone => $req );
}

=item B<reportDone>

����:

˵���������ϴ��������

=cut
sub reportDone {
    my ($kernel, $session, $heap) = @_[ KERNEL, SESSION, HEAP ];
    my ($req, $res) = @_[ ARG0..$#_ ];

    my $httpRequest     = $req->[0];
    my $httpResponse    = $res->[0];

    runlog( API => "�ļ���������ϱ�����Ӧ��" );
   
    if ( not $httpResponse->is_success ){
        warnlog( SRT => "�ļ���������ϱ�ʧ�ܡ�" );
        delTimeoutData( $heap );
        $heap->{status} = 'failed';
        return;
    }
    
    $heap->{dataList} = {};
    $heap->{dataList} = $heap->{tmpDataList};
    $heap->{tmpDataList} = {};
    $heap->{status} = 'ready';
    return;    
}

sub addInfo {
    my ($kernel, $session, $heap) = @_[ KERNEL, SESSION, HEAP ];
    my ($file, $info, $status) = @_[ARG0, ARG1, ARG2];
    
    my $listType = $heap->{status} eq 'ready' ? 'dataList' : 'tmpDataList';

    $heap->{$listType}{$status}{$file}{data} = $info;
    $heap->{$listType}{$status}{$file}{timestamp} = time;
    delete $heap->{$listType}{todo}{$file} if $status eq 'done';
}

sub delTimeoutData {
    my $heap = shift;
    my $now = time;
    my @files = keys %{$heap->{dataList}{done}};
    
    foreach my $file ( @files ){
        if ( $now - $heap->{dataList}{done}{$file}{timestamp} > $heap->{shelflife} ){
            delete $heap->{dataList}{done}{$file};
        }
    }

    @files = keys %{$heap->{dataList}{todo}};
    
    foreach my $file ( @files ){
        if ( $now - $heap->{dataList}{todo}{$file}{timestamp} > $heap->{shelflife} ){
            delete $heap->{dataList}{todo}{$file};
        }
    }

    @files = keys %{$heap->{tmpDataList}{todo}};
    
    foreach my $file ( @files ){
        if ( $now - $heap->{tmpDataList}{todo}{$file}{timestamp} > $heap->{shelflife} ){
            delete $heap->{tmpDataList}{todo}{$file};
        }
    }

    @files = keys %{$heap->{tmpDataList}{done}};
    
    foreach my $file ( @files ){
        if ( $now - $heap->{tmpDataList}{done}{$file}{timestamp} > $heap->{shelflife} ){
            delete $heap->{tmpDataList}{done}{$file};
        }
    }
}

1;
