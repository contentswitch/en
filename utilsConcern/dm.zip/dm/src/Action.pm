# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package Action;

use strict;
use warnings;
use Smart::Comments -ENV, '###';
use Clone qw(clone);

use Action::MultiUpload;
use Action::Upload;
use Action::Rotate;
use Action::Clean;
use Action::Move;
use Action::Monitor;

sub spawn {
    my $self = shift;
    my $dirDesc = shift;

    my $action = $dirDesc->{Action};
    my $class = "Action::$action";

    my $session = create POE::Session(
        package_states => [
            $class => [ qw( _start init loop process shutdown _stop ) ],
        ],
        heap => {
            class   => $class,
            dirDesc => clone $dirDesc,
        },
    );

    return $session;
}

1;
