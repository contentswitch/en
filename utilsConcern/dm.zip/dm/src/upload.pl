#!/usr/bin/perl

use strict;
use warnings;
use Smart::Comments;

use POE;
use PoeHelper;

use DirectoryWatcher;
use FtpClient;
use Utils;

my $path = shift;
my $ip = shift;
if ( not defined $path or not -d $path ){
    die "Usage: $0 <path>\n";
}

spawnSession( qw(newFilesFound uploadDone uploadFailed), { cfg => { path => $path, ip => $ip } } );

run POE::Kernel;

exit 0;

event _start {
    alias_set( 'mainSession' );
    runlog( TST => '���Գ���������' );

    spawn DirectoryWatcher();

    spawn FtpClient({
        Concurrent  => 10,
    });

    post DW => findNewFiles => FcAccessLog => {
        Path        => $cfg->{path},
        Pattern     => '*.log',
        Interval    => 60,
        QueueLength => 10,
    } => newFilesFound => {};
}

event newFilesFound( $cbArgs, $files ){
    foreach my $file ( @$files ){
        post FTP => upload => {
            file    => $file,
            ip      => $cfg->{ip} || '119.147.106.99',
            port    => 21,
            type    => 'vsftpd',
            mode    => 'port',
            user    => 'fromcf',
            pass    => 'fromcf102090',
            dstPath => '/proclog/2nd_edition/flexicache/upload',
            postfix => '.tmp',
            retry   => 3,
        };
    }
}

=item B<uploadDone>

����: ������Ϣ

˵��: �ϴ����֪ͨ

=cut
event uploadDone( $taskInfo, $speed, $ms ){
    runlog( TST => '�ļ�', $taskInfo->{file}, '�Ѿ�������ɡ�' );
    unlink $taskInfo->{file};
    post DW => findNewFiles => FcAccessLog => {};
}

=item B<uploadFailed>

����: ������Ϣ

˵��: �ϴ�ʧ��֪ͨ���������ע��� MFTT �˵� task.h ����һ��

=cut
event uploadFailed( $taskInfo, $errType, $errCode, $errMsg ){
    runlog( TST => '�ļ�', $taskInfo->{file}, "�ڴ���ʱ���� $errType ����: [$errCode] $errMsg" );
    post FTP => upload => {
        file    => $taskInfo->{file},
        ip      => $cfg->{ip} || '119.147.106.99',
        port    => 21,
        type    => 'vsftpd',
        mode    => 'port',
        user    => 'fromcf',
        pass    => 'fromcf102090',
        dstPath => '/proclog/2nd_edition/flexicache/upload',
        postfix => '.tmp',
    };
}
