#!/usr/bin/env perl
# vim: set et sta ts=4 sw=4 sts=4:

use strict;
use warnings;

use IO::Socket;
use List::Util qw(max);
use Perl6::Junction qw(all);
use POSIX;
use Smart::Comments;
use Data::Dumper;

use POE::Component::IKC::ClientLite;
use POE::Component::IKC::Freezer;

sub usage {
    print STDERR <<EOT;
�÷�: $0 <����> <����>

�����ڴ�

EOT
    exit 0;
}

POSIX::close($_) foreach(3..1024);

my $action = shift or usage();
my @args = @ARGV;

if ( $action eq 'list' ){
    list();
}
elsif ( $action eq 'show' ){
    my $session = $args[0];
    show( $session );
}
elsif ( $action eq 'status' ){
    status();
}
elsif ( $action eq 'detail' ){
    detail();
}
elsif ( $action eq 'debug' ){
    my $sub = shift @args;
    debug( $sub, @args );
}
elsif ( $action eq 'backdoor' ){
    my $cmd = join ' ', @args;
    backdoor( $cmd );
}
else{
    print STDERR "���������: $action\n";
    usage();
}

sub list {
    my $sessionList = callDMd( 'list' );

    my @table;
    push @table, [ qw(ID ����) ];

    foreach my $id ( sort { $a <=> $b } keys %$sessionList ){
        my @aliasList = @{ $sessionList->{$id} };
        my $aliasString = @aliasList == 0 ? '(û�б���)' : join ' ', @aliasList;
        push @table, [ $id, $aliasString ];
    }

    showTable( @table );
}

sub show {
    my $session = shift;

    my $heap = callDMd( show => $session );

    if ( not defined $heap ){
        print "���� BUG��δ����ȷ�õ� Session $session �� heap\n";
        return;
    }

    if ( ref $heap ){
        print Dumper( $heap );
    }
    else {
        print $heap, "\n";
    }
}

sub status {
    my $result = callDMd( 'status' );
    
    my @table;
    push @table, [ qw(���� ����Ŀ�� Ŀ���豸 �������ļ��� �������) ];

    my ($name, $dstApp, $dstDev, $server, $todo, $backup, $group);

    foreach my $dir ( %$result ){

        $name = $result->{$dir}{name};
        $backup = $result->{$dir}{backup};

        foreach my $dest ( keys %{ $result->{$dir}{upload} } ){

            $group = $result->{$dir}{upload}{$dest};
            $dstApp = $dest;

            foreach my $gName ( keys %$group ){

                $todo = $group->{$gName}{todo};
                $server = $group->{$gName}{server};
                push @table, [ $name, $dstApp, $server, $todo, $backup ];
                $name = "";
                $dstApp = "";

            }

        }

    }
        
    showTable( @table );
}

sub detail {
    my $result = callDMd( 'status' );
    
    my @table;
    push @table, [ qw(���� �ϴ�Ŀ¼ ����Ŀ�� Ŀ���豸 Ŀ��Ŀ¼ �������ļ��� �������) ];

    my ($name, $dstApp, $dstDev, $server, $todo, $backup, $group);
    my ($srcPath, $dstPath);

    foreach my $dir ( %$result ){

        $name = $result->{$dir}{name};
        $backup = $result->{$dir}{backup};

        foreach my $dest ( keys %{ $result->{$dir}{upload} } ){

            $group = $result->{$dir}{upload}{$dest};
            $dstApp = $dest;
            $srcPath = $result->{$dir}{path}{$dest}{src};
            $dstPath = $result->{$dir}{path}{$dest}{dest};

            foreach my $gName ( keys %$group ){

                $todo = $group->{$gName}{todo};
                $server = $group->{$gName}{server};
                push @table, [ $name, $srcPath, $dstApp, $server, $dstPath, $todo, $backup ];
                $name = "";
                $dstApp = "";
                $srcPath = "";
                $dstPath = "";
            }

        }

    }
        
    showTable( @table );
}

sub debug {
    my $sub = shift or return;
    my @args = @_;

    my $result = callDMd( debug => $sub => @args );

    if ( @$result > 1 ){
        print Dumper( $result );
    }
    elsif ( ref $result->[0] ){
        print Dumper( $result->[0] );
    }
    elsif ( defined $result->[0] ){
        print "return: ", $result->[0], "\n";
    }
    else{
        print "return: <undef>\n";
    }
}

sub backdoor {
    my $cmd = shift;

    my $result = callDMd( backdoor => $cmd );
    if ( not defined $result ){
        print "result: <undef>\n";
        return;
    }
    elsif ( ref $result ){
        print Dumper( $result );
        return;
    }
    else{
        chomp $result;
        print $result, "\n";
        return;
    }
}

sub callDMd {
    my $cmd = shift or return;
    my @args = @_;

    my $ip = '127.0.0.1';

    my $poe = create_ikc_client(
        ip          => $ip,
        port        => 22000,
        name        => "DmCli$$",
        serialiser  => 'POE::Component::IKC::Freezer',
    ) or die "DM û�����С�\n";

    return $poe->call( "control/$cmd", @args ) or die $poe->error;
}

sub showTable {
    my @table = @_;

    my @len;
    foreach my $row (@table){
        foreach my $colIndex ( 0..$#$row-1 ) {
            $row->[$colIndex] = '' if not defined $row->[$colIndex];
            my $maxColLen = $len[ $colIndex ];
            my $curColLen = length $row->[$colIndex];
            if ( not defined $maxColLen or $curColLen > $maxColLen ){
                $len[ $colIndex ] = $curColLen;
            }
        }
    }

    my $fmt = join ' ', map { "A$_" } map { $_+1 } @len;
    $fmt .= ' A*';

    foreach my $row (@table){
        print pack $fmt, @$row;
        print "\n";
    }
}
