# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package CtrlInterface;

use strict;
use warnings;
use Smart::Comments -ENV, '###';
use Data::Dumper;
use List::MoreUtils qw(any);

use base qw(Exporter);
our @EXPORT = qw(startCtrlPort);

use POE qw(Component::IKC::Server Component::IKC::Responder Component::IKC::Freezer);
use POE::API::Peek;

use FindBin;
use lib "$FindBin::Bin";
use Utils;
use ConfigFile;

my @supportCmd = qw(list show status debug backdoor);

sub startCtrlPort {
    create POE::Session(
        package_states => [
            (__PACKAGE__)   => [ '_start', @supportCmd ],
        ],

        heap => {
            mainHeap    => $_[HEAP],
            mainSession => $_[SESSION],
        },
    );
}

sub _start {
    my ($kernel, $heap) = @_[ KERNEL, HEAP ];

    $kernel->alias_set( 'control' );

    create_ikc_server(
        port    => 22000,
        name    => 'DM',
    ) or errlog( APP => "�򿪿��ƶ˿�ʧ��:" . POE::Component::IKC::Server::error() );
    
    create_ikc_responder();

    $ikc->publish( 'control', [ @supportCmd ] );

    $heap->{api} = new POE::API::Peek;
}

sub list {
    my ($kernel, $heap) = @_[ KERNEL, HEAP ];
    my $api = $heap->{api};

    # ��Ҫ���˵� Kernel ����
    my @sessions = grep { $_->ID =~ /^\d+$/ } $api->session_list();

    my %sessionAlias = map { $_->ID, [ $api->session_alias_list( $_ ) ] } @sessions;

    return \%sessionAlias;
}

sub show {
    my ($kernel, $heap) = @_[ KERNEL, HEAP ];
    my $sessionID = $_[ ARG0 ];

    my $api = $heap->{api};

    my $session = $api->resolve_session_to_ref( $sessionID );
    $session = $api->resolve_alias( $sessionID ) if not defined $session;
    return 'û����� Session��' if not defined $session;

    return $session->get_heap();
}

sub status {
    my ($kernel, $heap) = @_[ KERNEL, HEAP ];
    my $mainSession = $heap->{mainSession};

    my $status = $kernel->call( $mainSession => 'getUploadStatus' );

    return $status; 
}

sub debug {
    my ($kernel, $heap) = @_[ KERNEL, HEAP ];
    my ($sub, @args) = @_[ ARG0..$#_ ];

    my $api = $heap->{api};

    @args = map { $_ !~ /SESSION_(\S+)/ ? $_ : $api->resolve_session_to_ref( $_ ) } @args;

    my @ret = eval{ $api->$sub( @args ) };

    if ( $@ ){
        return $@;
    }
    else{
        return \@ret;
    }
}

sub backdoor {
    my ($kernel, $heap, @args) = @_[ KERNEL, HEAP, ARG0..$#_ ];
    my $mainHeap = $heap->{mainHeap};

    my $sth = join ' ', @args;

    my $output = eval $sth;

    if ( defined $@ ){
        return $@;
    }

    return $output;
}

1;
