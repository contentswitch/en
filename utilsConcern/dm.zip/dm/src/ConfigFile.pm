# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package ConfigFile;

use strict;
use warnings;
use Smart::Comments -ENV, '###';
use Perl6::Junction qw(one);
use Clone qw(clone);

use base qw(Exporter);

our @EXPORT = qw(
    loadConfig
    setConfig
    getConfig
    getAllDirDesc
    getDirDesc
    getDirByApp
    getAccByApp
    updateConfig
    getDefaultTarget
    setDirDesc
    getSpecialConfig
);

use File::Spec::Functions;
use File::Basename;
use Time::Local;
use FindBin;
use YAML qw(LoadFile DumpFile);

use Utils;

my $globalConfig = {};
my $dirDesc = {};
my $rule = {};
my $defaultDirDesc = {};
my $specialDirDesc = {};

################################################################
# ���������ļ��������
# 1, ����ȱʡ����
# 2, �����û����ã��������⴫�����ã�
# 3, ���������ã����ݣ�
sub loadConfig {
    my $fileName = shift;

    loadDefaultConfig();

    loadGlobalConfig();
    loadDirConfig();

    ### $globalConfig
    ### $dirDesc

    return;
}

sub loadDefaultConfig {
    $globalConfig = eval{ LoadFile( "$FindBin::Bin/../etc/config.yaml.default" ) } || {};
    $globalConfig->{Hostname} = getHostname();
    $globalConfig->{DeviceID} = getDeviceID();

    $globalConfig->{UploadOptions}->{RefreshDeviceListInterval}
        = extendTime( $globalConfig->{UploadOptions}{RefreshDeviceListInterval} ) || 1800;

    $globalConfig->{UploadOptions}->{DeviceShelflife}
        = extendTime( $globalConfig->{UploadOptions}{DeviceShelflife} ) || 6 * 3600;

    loadDirConfig( '.yaml.default' );
}

sub loadGlobalConfig {
    my $file = shift || "$FindBin::Bin/../etc/config.yaml";

    my $deviceId = getDeviceID();
    if ( defined $globalConfig->{DeviceID} and $globalConfig->{DeviceID} ne $deviceId ){
        # TODO: �豸 SN �����˱仯
        $globalConfig->{DeviceID} = $deviceId;
    }

    my $hostname = getHostname();
    if ( defined $globalConfig->{Hostname} and $globalConfig->{Hostname} ne $hostname ){
        # TODO: hostname �����˱仯
        $globalConfig->{Hostname} = $hostname;
    }

    return unless -f $file;
    my $config = eval{ LoadFile( $file ) } || {};

    foreach my $key (%$config){
        $globalConfig->{$key} = $config->{$key};
    }
}

sub loadDirConfig {
    my $postfix = shift || '.yaml';

    my $pattern = catfile( "$FindBin::Bin/../etc/dir.d/", "*$postfix" );
    foreach my $file ( glob $pattern ){
        my $appName = basename( $file, $postfix );
        my $dirs = eval{ LoadFile( $file ) } || [];
        foreach my $dir (@$dirs){
            my $name = $dir->{Name};
            if ( not defined $name ){
                errlog( CFG => "������ȱ�� Name �ֶΡ�" );
                next;
            }

            $dir->{Application} ||= 'etc';

            $dir->{CheckInterval} = extendTime( $dir->{CheckInterval} ) || 10 if defined $dir->{CheckInterval};

            if ( not defined $dir->{Path} ){
                errlog( CFG => "Ŀ¼ $name ��������ȱ�� Path �ֶΡ�" );
                next;
            }

            if ( not defined $dir->{Action} ){
                errlog( CFG => "Ŀ¼ $name ��������ȱ�� Action �ֶΡ�" );
                next;
            }

            if ( $dir->{Action} !~ /^(Tar|Rotate|Move|Clean|Monitor|Upload|MultiUpload)$/ ) {
                errlog( CFG => "Ŀ¼ $name ���õ� Action ����ʶ��" );
                next;
            }

            $defaultDirDesc->{$name} = clone $dir if $postfix eq '.yaml.default';
            $dirDesc->{$name} = $dir;
            $specialDirDesc->{$name} = $dir if $appName eq 'special';
        }
    }
}

sub setConfig {
    my $name = shift;
    my $value = shift;

    my $oldValue = $globalConfig->{$name};
    $globalConfig->{$name} = $value;

    return $oldValue;
}

sub getConfig {
    my $name = shift;

    return $globalConfig->{$name};
}

sub getDirDesc {
    my $dirName = shift;

    return $dirDesc->{$dirName};
}

sub getDirByApp {
    my @apps = @_;

    my @dirName;
    foreach my $app (@apps){
        push @dirName, grep {
            $dirDesc->{$_}->{Application} eq $app
        } keys %$dirDesc;
    }

    return @dirName;
}

sub getAccByApp {
    my $appName = shift;
    return $globalConfig->{UploadOptions}{FtpAccount}{$appName};
}

sub setDirDesc {
    my ($name, $desc) = @_;
    
    $dirDesc->{$name} = clone $desc;
}

sub updateConfig {
    my $chgDir = shift;
    my $res;

    foreach my $dir ( @$chgDir ){
        $specialDirDesc->{$dir} = $dirDesc->{$dir};
    }   
    
    foreach my $dir ( keys %$specialDirDesc ){
        push @$res, $specialDirDesc->{$dir};
    }
    
    DumpFile( "$FindBin::Bin/../etc/dir.d/special.yaml", $res );
}

sub getDefaultTarget {
    my ($dir, $dest) = @_;
    return $defaultDirDesc->{$dir}{UploadOptions}{WhereTo}{$dest};
}

sub getSpecialConfig {
    return $specialDirDesc;
}

1;
