# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package CsmInterface;

use strict;
use warnings;
use base qw(Exporter);

use File::Copy;

our @EXPORT = qw(initCSM 
                 setOID 
                 touchCSM
                 updatePreComm
                 updatePostComm
                 updateBackupStatus
              );

#----------------
# �������/����������� SNMP ��Ϣ��
our %gSnmpPool = ();

#----------------
# monitor pool �ļ�·��
my $poolFile;

#----------------
# pool �ļ���ÿ����Ϣ�����֡�
my @oids = qw(
    status
    badPathCount
    backupStatus
    preCommStatus
    postCommStatus
);

#----------------
# Move ���� preCommand ִ�еĽ��
my %preCommStatus;

#----------------
# Move ���� postCommand ִ�еĽ��
my %postCommStatus;

#----------------
# Upload/MultiUpload �ϴ��ļ�֮�󱸷����
my %backupStatus;

################################################################
# ��ʼ�� CSM
#
sub initCSM {
    my $fileName = shift;

    $poolFile = $fileName;

    return 1;
}

################################################################
# ���� OID ��ֵ
#
sub setOID {
    my ($name, $value) = @_;
    $gSnmpPool{$name} = $value;

    touchCSM();
}

################################################################
# ���ڸ��� SNMP pool �ļ�
#
sub touchCSM {
    open my $fh, '>', $poolFile . '~' or return;

    foreach my $oid ( @oids ){
        my $value = $gSnmpPool{$oid};
        $value = '' if not defined $value;
        print $fh "$oid: $value\n";
    }

    close $fh;

    move( $poolFile . '~', $poolFile );
}

################################################################
# ���� PreComm ״̬
#
sub updatePreComm {
    my ($dirName, $val) = @_;

    $preCommStatus{$dirName} = $val;

    my @dirs = grep { $preCommStatus{$_} != 0 } keys %preCommStatus;
    if ( @dirs ){
        $gSnmpPool{preCommStatus} = 1;
    }
    else {
        $gSnmpPool{preCommStatus} = 0;
    }

}

################################################################
# ���� PostComm ״̬
#
sub updatePostComm {
    my ($dirName, $val) = @_;

    $postCommStatus{$dirName} = $val;

    my @dirs = grep { $postCommStatus{$_} != 0 } keys %postCommStatus;
    if ( @dirs ){
        $gSnmpPool{postCommStatus} = 1;
    }
    else {
        $gSnmpPool{postCommStatus} = 0;
    }

}

################################################################
# ���� backup ״̬
#
sub updateBackupStatus {
    my ($dirName, $val) = @_;

    $backupStatus{$dirName} = $val;

    my @dirs = grep { $backupStatus{$_} ne 'normal' } keys %backupStatus;
    if ( @dirs ){
        $gSnmpPool{backupStatus} = 1;
    }
    else {
        $gSnmpPool{backupStatus} = 0;
    }

}

1;
