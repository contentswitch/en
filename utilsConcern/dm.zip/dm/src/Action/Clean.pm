# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package Action::Clean;

use strict;
use warnings;

use File::Spec::Functions;
use File::Copy;
use File::Find;
use Text::Glob qw(match_glob);
use Filesys::Df;
use ConfigFile; 
use POE;

use Action::Common;
use Utils;
use Smart::Comments -ENV, '###';

sub init {
    my ($kernel, $session, $heap) = @_[KERNEL, SESSION, HEAP];
    my $dirDesc = $heap->{dirDesc};
    my $dirName = $dirDesc->{Name};

    if (    not defined $dirDesc->{When}{SizeLimit}
        and not defined $dirDesc->{When}{TimeLimit}
        and not defined $dirDesc->{When}{DiskUsedLimit}
        and not defined $dirDesc->{When}{NumberLimit} ){
        errlog( CLN => "Ŀ¼ $dirName ��������û�и�������������" );
        return -1;
    }
    if ( not defined $dirDesc->{MaxDepth} ){
        $dirDesc->{MaxDepth} = 1;
    }
    if ( defined $dirDesc->{Exclude} ){
        my @exlist = split (/,/, $dirDesc->{Exclude});
        delete $dirDesc->{Exclude};
        foreach my $exfile ( @exlist ){
            $dirDesc->{Exclude}{$exfile} = undef;
        }
    }

    # ��ʼ�� TimeLimit SizeLimit  NumberLimit    DiskUsedLimit
    if ( defined $dirDesc->{When}{TimeLimit} ){
        $dirDesc->{When}{TimeLimit} = extendTime( $dirDesc->{When}{TimeLimit} ); 
    }

    if ( defined $dirDesc->{When}{NumberLimit} ){
        my $until = $dirDesc->{When}{NumberLimit};
        $until = $dirDesc->{Until}{NumberLimit} if defined $dirDesc->{Until}{NumberLimit} and $dirDesc->{Until}{NumberLimit} < $until;
        $dirDesc->{Until}{NumberLimit} = $until;
    }

    if ( defined $dirDesc->{When}{SizeLimit} ){
        $dirDesc->{When}{SizeLimit} = extendSize( $dirDesc->{When}{SizeLimit} );
        my $until = $dirDesc->{When}{SizeLimit};
        $until = extendSize( $dirDesc->{Until}{SizeLimit} ) if defined $dirDesc->{Until}{SizeLimit} and extendSize( $dirDesc->{Until}{SizeLimit} ) < $until;
        $dirDesc->{Until}{SizeLimit} = $until;
    }

    if ( defined $dirDesc->{When}{DiskUsedLimit} ){
        if ( $dirDesc->{When}{DiskUsedLimit} =~ /%$/ ){
            $dirDesc->{DiskUsedLimitFlag} = "percent";
            $dirDesc->{When}{DiskUsedLimit} =~ s/%$//;

            my $limit = $dirDesc->{When}{DiskUsedLimit};
            my $untilLimit = $dirDesc->{Until}{DiskUsedLimit};

            if ( defined $untilLimit ){
                if ( $untilLimit !~ /%$/ ){
                    errlog( CLN => "Ŀ¼ $dirName ���������������� Until ������ DiskUsedLimit Ӧ��ʹ�ðٷֱȡ�" );
                    return -1;
                }
                else {
                    $untilLimit =~ s/%$//;
                    $limit = $untilLimit if $untilLimit < $limit;
                }
            }

            $dirDesc->{Until}{DiskUsedLimit} = $limit;
        }
        else{
            $dirDesc->{DiskUsedLimitFlag} = "size";
            $dirDesc->{When}{DiskUsedLimit} = extendSize( $dirDesc->{When}{DiskUsedLimit} );

            my $limit = $dirDesc->{When}{DiskUsedLimit};
            my $untilLimit = $dirDesc->{Until}{DiskUsedLimit};

            if ( defined  $untilLimit ){
                if ( $untilLimit =~ /%$/ ){
                    errlog( CLN => "Ŀ¼ $dirName ���������������� Until ������ DiskUsedLimit Ӧ��ʹ�ðٷֱȡ�" );
                    return -1;
                }
                else {
                    $untilLimit = extendSize( $untilLimit );
                    $limit = $untilLimit if $untilLimit < $limit;
                }
            }    

            $dirDesc->{Until}{DiskUsedLimit} = $limit;
        }
    }

    # Until �������9�۴���
    foreach my $item (keys %{ $dirDesc->{Until} } ){
        $dirDesc->{Until}{$item} = int ( $dirDesc->{Until}{$item} * 0.9 );
    }
    $heap->{todo} = []; 
    addEvents( 'doClean' );

    return;
}

sub process {
    my ($kernel, $session, $heap) = @_[KERNEL, SESSION, HEAP];
    my $dirDesc = $heap->{dirDesc};
    my $dirName = $dirDesc->{Name};
    
    return if @{ $heap->{todo} } > 0;

    my $now = time();

    runlog( CLN => "��� $dirName Ŀ¼....." );

    my %allInodeInfo;
    my $sumSize = 0;
    my $depth = 0;
    if ( not -d $dirDesc->{Path} ){
        runlog( CLN => "$dirName Ŀ¼�в����ڣ�������" );
        return;
    }

    find({
        preprocess => sub {
            my @F = @_;
            my @files;
            $depth++;
            my $dirname = "$File::Find::dir";
            return () if exists $dirDesc->{Exclude}{$dirname};
            return () if $depth > $dirDesc->{MaxDepth};
            foreach my $f ( @F ){
                my $fullname = "$File::Find::dir/$f";
                next if exists $dirDesc->{Exclude}{$fullname};
                push  @files, $f;
            }
            return @files;
        },
        wanted => sub {
            my $fullName = $File::Find::name;

            # ����ֻ���ļ���������Ŀ¼������
            return unless -f $fullName;
            return if defined $dirDesc->{FileNamePattern} and not match_glob( $dirDesc->{FileNamePattern}, $_ );

            my ($inode, $size, $mtime, $blocks) = (stat($fullName))[1, 7, 9, 12];
            $size = 512 * $blocks;

            if (    defined $dirDesc->{When}{TimeLimit} # �����ѡ��
                and $now - $mtime >= $dirDesc->{When}{TimeLimit} ){
                # ��������ļ�����ɾ������
                unlink $fullName and runlog( CLN => "�ļ� $fullName ��Ϊ�ﵽʱ�����Ʊ�ɾ����" );
            }
            else{
                # ��������ϵĻ�.
                if ( not exists $allInodeInfo{$inode} ){
                    $allInodeInfo{$inode}{mtime} = $mtime;
                    $allInodeInfo{$inode}{size} = $size;
                    
                    $sumSize += $size; 
                }
                push ( @{$allInodeInfo{$inode}{filename}} ,$fullName);
            }
        },
        postprocess => sub {
            $depth--;
            my $dirname = "$File::Find::dir";
            # TOP Ŀ¼�ɲ���ɾ������Ȼ��û�����ˡ�
            return if inodeOf( $File::Find::dir ) == inodeOf( $dirDesc->{Path} );

            return if not exists $dirDesc->{When}{TimeLimt};

            my $mtime = lastModifyTime( $File::Find::dir );
            return if $now - $mtime < $dirDesc->{When}{TimeLimit};

            # ���£����Ŀ¼���ǿյģ�rmdir ʲôҲ������^_^
            if ( rmdir $File::Find::dir ){
                runlog( CLN => "ɾ����Ŀ¼ $File::Find::dir��" );
            }
            else{
                runlog( CLN => "Ŀ¼ $File::Find::dir ɾ��ʧ�ܡ�" );
            }
        }
    }, $dirDesc->{Path} );
    analyze( $heap, $dirDesc, $sumSize, %allInodeInfo );  

    $kernel->yield( 'doClean' );

}

sub analyze {
    my ($heap, $dirDesc, $sumSize, %allInodeInfo) = @_;

    # ��ʱ������һ��û�й��ڵ��ļ��� %allInodeInfo Ԫ�ء�
    # �����ٸ���Ŀ¼��С���ļ����������ߴ��̿ռ�����ȥɾ�����ϵ��ļ���
    my @allInode = sort { $allInodeInfo{$a}{mtime} <=> $allInodeInfo{$b}{mtime} } keys %allInodeInfo;
    my $fileCnt = 0;
    my $oldSize = $sumSize;

    map {
        $fileCnt += @{$allInodeInfo{$_}{filename}}
    } @allInode;

    if (    defined $dirDesc->{When}{NumberLimit}
        and $fileCnt > $dirDesc->{When}{NumberLimit} ){

        while (     $fileCnt > $dirDesc->{Until}{NumberLimit} 
                and @allInode > 0 ){
            queueUp( $heap, \$sumSize, \$fileCnt, \@allInode, \%allInodeInfo, '�ļ�����');
        }

    }

    if (    defined $dirDesc->{When}{SizeLimit}
        and $sumSize > $dirDesc->{When}{SizeLimit} ){

        while (     $fileCnt > $dirDesc->{Until}{SizeLimit}
                and @allInode > 0 ){
            queueUp( $heap, \$sumSize, \$fileCnt, \@allInode, \%allInodeInfo, '�ļ���С');
        }

    }

    return if @allInode == 0 or not exists $dirDesc->{When}{DiskUsedLimit};

    my $dfInfo = df( $dirDesc->{Path}, 1);

    return if $dfInfo->{per} == 0;

    my $totalSize = $dfInfo->{used} / $dfInfo->{per} * 100;
    my $percent = $dfInfo->{per} - ( $oldSize - $sumSize ) / $totalSize * 100;
    my $diskSize = $dfInfo->{used} - ( $oldSize - $sumSize );

    if (    $dirDesc->{DiskUsedLimitFlag} eq 'percent' 
        and $percent > $dirDesc->{When}{DiskUsedLimit} ){

        while (     $percent > $dirDesc->{Until}{DiskUsedLimit}
                and @allInode > 0 ){
            queueUp( $heap, \$sumSize, \$fileCnt, \@allInode, \%allInodeInfo, '����ռ�ÿռ�');
            $percent = $dfInfo->{per} - ( $oldSize - $sumSize ) / $totalSize * 100;
        }

    }
    elsif (    $dirDesc->{DiskUsedLimitFlag} eq 'size'
           and $diskSize > $dirDesc->{When}{DiskUsedLimit} ){

        while (     $diskSize > $dirDesc->{Until}{DiskUsedLimit}
                and @allInode > 0 ){
            queueUp( $heap, \$sumSize, \$fileCnt, \@allInode, \%allInodeInfo, '����ռ�ÿռ�');
            $diskSize = $dfInfo->{used} - ( $oldSize - $sumSize );
        }

    }

}

sub queueUp {
    my ($heap, $sumSize, $fileCnt, $allInode, $allInodeInfo, $reason) = @_;
    my $inode = shift @$allInode;

    $$sumSize -= $allInodeInfo->{$inode}{size};

    foreach my $file ( @{$allInodeInfo->{$inode}{filename}} ){
        push @{$heap->{todo}}, $file;
        $$fileCnt--;
        $heap->{reason}{$file} = $reason;
    }

}

sub doClean {
    my ($kernel, $session, $heap) = @_[KERNEL, SESSION, HEAP];
    my $count = 0;
    my $num = getConfig( 'CountOfFilePerClean' );
    my $file;

    return if @{$heap->{todo}} == 0;

    while ( $file = shift @{$heap->{todo}} ){
        $count++;
        if ( unlink $file ){
            runlog( CLN => "�ļ� $file ��Ϊ�ﵽ$heap->{reason}{$file}���Ʊ�ɾ��" );
        }
        else{
            runlog( CLN => "�ļ� $file ɾ��ʧ�ܡ�" );
        }
        
        delete $heap->{reason}{$file};

        last if $count == $num;
        
    }
    
    $kernel->yield( 'doClean' );
}

1;
