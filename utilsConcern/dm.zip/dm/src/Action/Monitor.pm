# vim: set et sta ts=4 sw=4 sts=4:
# vi: set ts=4:

package Action::Monitor;

use strict;
use warnings;
use Smart::Comments '###';

use File::Spec::Functions;
use File::Copy;

use POE;

use Action::Common;
use Utils;

sub init {
}

sub process {
}

=jfc
sub monitor {
    my ($kernel, $heap, $section) = @_[KERNEL, HEAP, ARG0];
    my $target = $heap->{conf}->{$section};

    my @allFiles = glob( catfile( $target->{path}, '*' ) );
    if ( @allFiles == 0 ){
        $kernel->delay_set( 'monitor', $target->{interval}, $section );
        return;
    }

    my $now = time();
    my $sumSize = 0;
    my $count = 0;
    for my $file (@allFiles){
        my $mtime = (stat($file))[9];
        if ( $now - $mtime >= $target->{timelimit} ){
            $count ++;
        }

        $sumSize += -s $file;
    }

    my $needAlert = 0;

    if ( $count > 0 ){
        runlog( MNT => "Ŀ¼ ",  $target->{path}, " ���쳣����Ϊ $count ���ļ��Ĵ���ʱ��֮���Ѿ��������趨ֵ��" );
        $needAlert = 1;
    }

    if ( $sumSize > $target->{sizelimit} ){
        runlog( MNT => "Ŀ¼ ",  $target->{path}, " ���쳣����ΪĿ¼��С�Ѿ��������趨ֵ��" );
        $needAlert = 1;
    }

    if ( $needAlert ){
        $kernel->yield( 'alert', $target->{path}, $count, $sumSize );
    }
    else{
        $kernel->yield( 'alert', $target->{path} );
    }

    $kernel->delay_set( 'monitor', $target->{interval}, $section );
}
=cut

1;
