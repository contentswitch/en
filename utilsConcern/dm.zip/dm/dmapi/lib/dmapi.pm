package dmapi;
use Dancer ':syntax';
use Dancer::Plugin::Database;
use YAML::Syck;
use JSON::Syck ();
use DBI;
use LWP::UserAgent;
use FindBin;
use File::Spec;
use Smart::Comments;

our $VERSION = '0.1';
our %returnValCache = ();
our %devListCache = ();

our $conf = LoadFile( "$FindBin::Bin/../dmapi.conf.yaml" );
our $qqlist = $conf->{qqlist};

our $returnCacheThreshold = $conf->{returnCacheThreshold} || 120;
our $listCacheThreshold   = $conf->{listCacheThreshold} || 600;

get '/' => sub {
    return "hello, i am dmapi!";
};

get '/php/getDeviceByApp.php' => sub {
    my $appId    = params->{appId};
    my $hostname = params->{hostname};
    my $deviceId = params->{deviceID};  

    my $out = allRequest ( $hostname, $deviceId, $appId, \%returnValCache, \%devListCache ); 
    content_type 'text/plain';
    return $out;
};

get '/reloadConf' => sub {

    $conf = LoadFile( "$FindBin::Bin/../dmapi.conf.yaml" );
    $qqlist = $conf->{qqlist};

    $returnCacheThreshold = $conf->{returnCacheThreshold} || 120;
    $listCacheThreshold   = $conf->{listCacheThreshold} || 600;
    
    my $now = localtime;

    return "reload the config successful! $now";
};

#-----------------------------------------------------------------------------------------

sub getSwitchStatus {
    my $val  = shift;
    my %hash = ( 1, "disable", 2, "enable" );
    if ( exists $hash{$val} ) {
        return $hash{$val};
    }
    else {
        return "undef";
    }
}

sub getRealStatus {
    my $val  = shift;
    my %hash = ( 1, "shutdown", 2, "startup", 3, "running", 4, "faint", 5, "goingdown" );
    if ( exists $hash{$val} ) {
        return $hash{$val};
    }
    else {
        return "undef";
    }
}

sub otherRequest {
    my ( $hostname, $deviceId, $appId, $deviceType ) = @_;
    my $sql = <<SQL;
    select
        d.hostname,
        d.device_id,
        d.mip,
        a.set_status,
        a.real_status,
        a.dev_health,
        a.version,
        a.last_time
    from
        devmgmt_device d,
        devstatus_amr_data a
    where
        d.device_id=a.device_code
        and a.app_id=?
SQL
    my $result = database->selectall_hashref( $sql, "hostname", {}, $appId );
    return $result;
}

sub dataFormat {
    my $result   = shift;
    my $arrayref = [qw()];
    foreach my $server ( keys %$result ) {
        my $href = {};
        $href->{Health}     = $result->{$server}{dev_health};
        $href->{SN}         = $result->{$server}{device_id};
        $href->{Name}       = $result->{$server}{hostname};
        $href->{LastUpdate} = $result->{$server}{last_time};
        $href->{IP}         = $result->{$server}{mip};
        $href->{Status}     = getRealStatus ( $result->{$server}{real_status} );
        $href->{Switch}     = getSwitchStatus ( $result->{$server}{set_status} );
        $href->{Version}    = $result->{$server}{version};
        push @$arrayref, $href;
    }
    return $arrayref;
}


sub keaRequest {
    my ( $hostname, $deviceId, $appId, $deviceType ) = @_;
    my $specialNode = "BGP-BJ-9-3m"."%";
    my $sql = <<SQL;
    select
        d.node_type,
        d.hostname,
        d.device_id,
        d.mip,
        a.set_status,
        a.real_status,
        a.dev_health,
        a.version,
        a.last_time
    from
        devmgmt_device d,
        devstatus_amr_data a
    where
        d.device_id=a.device_code
        and a.app_id=?
SQL
    if ( $deviceType eq 'keaspecia') {
        $sql .= " and d.hostname like ?";
    }
    else{
        $sql .= " and d.hostname not like ?";
    }
    my $result = database->selectall_hashref( $sql, "hostname", {}, $appId, $specialNode );

    return $result;
}


sub nlaRequest {
    my ( $hostname, $deviceId, $appId, $deviceType ) = @_;
    my $specialNode = "CCN-BJ-J-3g"."%";
    my $sql = <<SQL;
    select
        d.node_type,
        d.hostname,
        d.device_id,
        d.mip,
        a.set_status,
        a.real_status,
        a.dev_health,
        a.version,
        a.last_time
    from
        devmgmt_device d,
        devstatus_amr_data a
    where
        d.device_id=a.device_code
        and a.app_id=?
SQL
    if ( $deviceType eq 'qq') {
        $sql .= " and d.hostname like ?";
    }
    elsif ( $deviceType eq 'china') {
        $sql .= " and d.node_type !='CCABROAD' and d.hostname not like ?";
    }
    else{
        $sql .= " and d.node_type !='CCABROAD' and d.hostname not like ?";
    }
    my $result = database->selectall_hashref( $sql, "hostname", {}, $appId, $specialNode );

    return $result;
}

sub allRequest {
    my ( $hostname, $deviceId, $appId, $returnCache, $listCache ) = @_;
    my $deviceType = getDeviceType( $appId, $hostname, $listCache );

    unless ( exists $returnCache->{$appId}{$deviceType}{output} && 
             time() - $returnCache->{$appId}{$deviceType}{lastUpdate} < 
             $returnCacheThreshold ) {

        my $result = '';
        my $cacheFile = File::Spec->catfile( "$FindBin::Bin/../cache", "$appId-$deviceType");
        $returnCache->{$appId}{$deviceType}{lastUpdate} = time();

        if ( $appId eq "200203010001" ) { # nla
            $result = nlaRequest( $hostname, $deviceId, $appId, $deviceType );
        }
        elsif( $appId eq "200303000158" ) { # kea
            $result = keaRequest( $hostname, $deviceId, $appId, $deviceType );
        }
        else {                            # other
            $result = otherRequest( $hostname, $deviceId, $appId, $deviceType );
        }

        if ( $result ) {
            my $arrayref  = dataFormat( $result );
            DumpFile ( $cacheFile, $arrayref ); 
            $returnCache->{$appId}{$deviceType}{output} = Dump $arrayref;
        }
        elsif ( exists $returnCache->{$appId}{$deviceType}{output} ){
        }
        elsif ( -e $cacheFile ) {
            my $arrayref = LoadFile ( $cacheFile ); 
            $returnCache->{$appId}{$deviceType}{output} = Dump $arrayref;
        } 
    }

    return $returnCache->{$appId}{$deviceType}{output};
}

sub getDeviceType {
    my ( $appId, $hostname, $listCache ) = @_;
    
    if ( $appId eq "200203010001" ) {
        return "qq"       if testTypeForQq( $hostname, $listCache );
        return "notchina" if testTypeForNotchina( $hostname, $listCache );
        return "china";   # set  default
    }
    elsif( $appId eq "200303000158" ) {
        return "keaspecia" if testTypeForKea( $hostname, $listCache );
        return "default";
    }
    else{
        return "default";
    }
}

sub testTypeForKea {
    my ( $hostname, $listCache ) = @_;
    my $cacheFile = File::Spec->catfile( "$FindBin::Bin/../cache", "kea-specia");

    unless ( exists $listCache->{keaspecia}{list} && 
             time() - $listCache->{keaspecia}{lastUpdate} < 
             $listCacheThreshold ) { 

        # reflash the qq devlist cahce from rcms
        $listCache->{keaspecia}{lastUpdate} = time();

        my $keaspecia = $conf->{keaspecia};
        $listCache->{keaspecia}{list} = $keaspecia;
        DumpFile ( $cacheFile, $listCache->{keaspecia}{list} ); 
    }
    return 1 if exists $listCache->{keaspecia}{list}{$hostname};
    return 0;
}

sub testTypeForQq {
    my ( $hostname, $listCache ) = @_;
    my $cacheFile = File::Spec->catfile( "$FindBin::Bin/../cache", "qq");

    unless ( exists $listCache->{qq}{list} && 
             time() - $listCache->{qq}{lastUpdate} < 
             $listCacheThreshold ) { 

        # reflash the qq devlist cahce from rcms
        $listCache->{qq}{lastUpdate} = time();
        my @urls = values %$qqlist; 
        my @array = ();
        my $num = 0;

        foreach my $url ( @urls ) {
            if ( my $val = lwpGet($url) ) {
                push @array, @{ JSON::Syck::Load($val) };
                $num++;
            }
        }
        
        if ( $num ne @urls ) {
            
            if ( exists $listCache->{qq}{list} ) {
                return 1 if exists $listCache->{qq}{list}{$hostname};
                return 0;
            }   
            elsif ( -e $cacheFile ) {
                $listCache->{qq}{list} = LoadFile( $cacheFile );
                return 1 if exists $listCache->{qq}{list}{$hostname};
                return 0;
            }
        }
                
        my %hash = map { $_->{name} => '' } @array;
        $listCache->{qq}{list} = \%hash;
        DumpFile ( $cacheFile, $listCache->{qq}{list} ); 
    }
    return 1 if exists $listCache->{qq}{list}{$hostname};
    return 0;
}

sub testTypeForNotchina {
    my ( $hostname, $listCache ) = @_;
    my $cacheFile = File::Spec->catfile( "$FindBin::Bin/../cache", "notchina");

    unless ( exists $listCache->{notchina}{list} && 
             time() - $listCache->{notchina}{lastUpdate} < 
             $listCacheThreshold ) { 
        
        # reflash the notchina list 
        $listCache->{notchina}{lastUpdate} = time();
        my $sql = <<SQL;
        select
            d.hostname
        from 
            devmgmt_device d 
        where 
            d.node_type ='CCABROAD'
SQL
        my $result = database->selectcol_arrayref( $sql );
        my %hash = map { $_ => ''} @$result;        
        $listCache->{notchina}{list} = \%hash;
        DumpFile ( $cacheFile, $listCache->{notchina}{list} ); 
    }

    return "1" if exists $listCache->{notchina}{list}{$hostname};
    return 0;
}

sub lwpGet {
    my ( $url ) = @_;
    my $ua = LWP::UserAgent->new;
    $ua->timeout( 10 );
    my $try = 2;
    while ( $try-- ) {
        my $response = $ua->get( $url );
        if ( $response->is_success ) {
            return $response->content;
        }
    }
    return;
}

true;
